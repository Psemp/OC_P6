class Quantity_stocks:

    def __init__(self, datadict):
        self.ingredient_id = datadict['ingredient_id']
        self.restaurant_id = datadict['restaurant_id']
